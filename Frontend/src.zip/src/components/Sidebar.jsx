import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiMenu, FiX } from 'react-icons/fi';

const navLinks = [
    { name: 'Tentang Saya', href: '#about' },
    { name: 'Keahlian', href: '#skills' },
    { name: 'Pengalaman', href: '#experience' },
    { name: 'Proyek', href: '#projects' },
    { name: 'Kontak', href: '#contact' },
];

const Sidebar = () => {
    const [isOpen, setIsOpen] = useState(false);

    const toggleSidebar = () => setIsOpen(!isOpen);

    return (
        <>
            <button onClick={toggleSidebar} className="fixed top-4 left-4 z-50 text-gray-300 md:hidden">
                {isOpen ? <FiX size={28} /> : <FiMenu size={28} />}
            </button>

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ x: '-100%' }} // Start off-screen
                        animate={{ x: 0 }} // Slide in
                        exit={{ x: '-100%' }} // Slide out
                        transition={{ duration: 0.3 }}
                        className="fixed top-0 left-0 h-full w-64 bg-neutral-900 shadow-lg z-40"
                    >
                        <div className="flex flex-col p-4">
                            {navLinks.map((link) => (
                                <a key={link.name} href={link.href} className="text-gray-300 hover:text-green-400 font-semibold transition-colors duration-300 mb-4">
                                    {link.name}
                                </a>
                            ))}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
};

export default Sidebar;