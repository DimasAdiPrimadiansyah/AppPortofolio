import React from 'react';
import Section from './layout/Section';
import Container from './layout/Container';
import AnimatedText from './ui/AnimatedText';

const ProfilePage = () => {
    return (
        <Section id="profile" className="bg-neutral-900 text-white py-10">
            <Container>
                <h1 className="text-4xl font-bold text-center mb-8">Profile</h1>
                <AnimatedText
                    text="Dimas Adi Primadiansyah"
                    className="text-3xl font-display font-bold text-white mb-2"
                />
                <p className="text-lg text-neutral-300 mb-4">Full-Stack Developer</p>
                <p className="text-lg text-neutral-300">
                    Saya adalah seorang Full-Stack Developer yang passionate dalam menciptakan solusi digital inovatif.
                </p>
            </Container>
        </Section>
    );
};

export default ProfilePage;
