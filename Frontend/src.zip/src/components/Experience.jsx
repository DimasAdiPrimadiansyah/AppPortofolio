// src/components/Experience.jsx

import React, { forwardRef } from 'react';
import { motion } from 'framer-motion';
import Section from './layout/Section';
import Container from './layout/Container';
import AnimatedText from './ui/AnimatedText';
import { FiBriefcase } from 'react-icons/fi';

const experiences = [
    {
        company: 'PT. Honda Prospect Motor',
        position: 'Operator Produksi',
        period: '2022',
        location: 'Cibinong, Bogor - Jawa Barat',
        description: 'Mengoperasikan mesin-mesin produksi untuk proses pemesinan dan perakitan mobil.',
    },
    {
        company: 'PT. Sepatu Mas Idaman',
        position: 'Quality Control',
        period: '2022',
        location: 'Cibinong, Bogor - Jawa Barat',
        description: 'Menjalankan fungsi kontrol kualitas produk dan memastikan hasil pemproduksian sesuai standar.',
    },
    {
        company: 'PT. Solusi Elektronik Indonesia',
        position: 'Teknis - Mesin Cuci',
        period: '2019 - 2021',
        location: 'Cibinong, Bogor - Jawa Barat',
        description: 'Memastikan produk yang dihasilkan untuk mendapatkan hasil yang maksimal.',
    }
];

const Experience = forwardRef((props, ref) => {
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.2,
                delayChildren: 0.2,
            },
        },
    };

    const cardVariants = {
        hidden: { y: 50, opacity: 0 },
        visible: {
            y: 0,
            opacity: 1,
            transition: {
                type: 'spring',
                stiffness: 100,
            },
        },
    };

    return (
        <Section id="experience" ref={ref} className="py-20 bg-neutral-900">
            <Container>
                <div className="text-center mb-16">
                    <AnimatedText
                        text="Professional Journey"
                        className="text-4xl lg:text-6xl font-display font-bold text-white mb-6"
                        variant="fadeUp"
                    />
                    <AnimatedText
                        text="Perjalanan karier saya di berbagai industri."
                        className="text-lg text-neutral-400"
                        variant="fadeUp"
                        delay={0.2}
                    />
                </div>

                <motion.div
                    className="relative"
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, amount: 0.2 }}
                    variants={containerVariants}
                >
                    <div className="absolute left-1/2 -ml-px w-0.5 h-full bg-neutral-700/50"></div>

                    {experiences.map((exp, index) => (
                        <motion.div
                            key={exp.company}
                            className="relative mb-12 flex items-center"
                            variants={cardVariants}
                        >
                            <div className={`flex w-full items-center ${index % 2 === 0 ? 'justify-start' : 'justify-end'}`}>
                                <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8' : 'pl-8 text-right'}`}>
                                    <motion.div
                                        className="bg-neutral-800 border border-white/10 p-6 rounded-xl shadow-lg transition-shadow duration-300 hover:shadow-primary-500/20"
                                        whileHover={{ y: -5, scale: 1.03 }}
                                    >
                                        <p className="text-sm text-neutral-400">{exp.period}</p>
                                        <h3 className="text-xl font-bold text-primary-300 mb-1">{exp.position}</h3>
                                        <p className="text-md font-semibold text-neutral-300 mb-3">{exp.company} - {exp.location}</p>
                                        <p className="text-neutral-400 leading-relaxed">{exp.description}</p>
                                    </motion.div>
                                </div>
                            </div>
                            <div className="absolute left-1/2 -ml-3 w-6 h-6 rounded-full bg-neutral-800 border-2 border-primary-400 flex items-center justify-center">
                                <FiBriefcase className="w-3 h-3 text-primary-400" />
                            </div>
                        </motion.div>
                    ))}
                </motion.div>
            </Container>
        </Section>
    );
});

export default Experience;
