import React from 'react';
import { motion } from 'framer-motion';
import GlassCard from './GlassCard';

const TimelineItem = ({
    year,
    title,
    company,
    description,
    technologies = [],
    isLast = false,
    delay = 0
}) => {
    return (
        <motion.div
            className="relative flex items-start space-x-6"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay }}
        >
            {/* Timeline Line */}
            <div className="flex flex-col items-center">
                <motion.div
                    className="w-4 h-4 rounded-full bg-gradient-to-r from-primary-500 to-accent-500 border-4 border-neutral-900 z-10"
                    whileHover={{ scale: 1.2 }}
                />
                {!isLast && (
                    <div className="w-0.5 h-24 bg-gradient-to-b from-primary-500/50 to-transparent mt-2" />
                )}
            </div>

            {/* Content */}
            <div className="flex-1 pb-8">
                <GlassCard className="p-6" hover>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3">
                        <h3 className="text-xl font-semibold text-white">{title}</h3>
                        <span className="text-sm text-primary-400 font-medium">{year}</span>
                    </div>

                    <p className="text-accent-300 font-medium mb-3">{company}</p>
                    <p className="text-neutral-300 leading-relaxed mb-4">{description}</p>

                    {technologies.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                            {technologies.map((tech, index) => (
                                <span
                                    key={tech}
                                    className="px-3 py-1 bg-white/10 rounded-full text-xs text-neutral-400 border border-white/20"
                                >
                                    {tech}
                                </span>
                            ))}
                        </div>
                    )}
                </GlassCard>
            </div>
        </motion.div>
    );
};

export default TimelineItem;
