import React from 'react';
import { motion } from 'framer-motion';
import GlassCard from './GlassCard';
import { FiCalendar, FiMapPin, FiExternalLink } from 'react-icons/fi';

const ExperienceCard = ({
    company,
    position,
    period,
    location,
    description,
    achievements = [],
    technologies = [],
    companyLogo,
    delay = 0
}) => {
    return (
        <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay }}
            className="relative"
        >
            <GlassCard className="p-6 group" hover>
                <div className="flex items-start space-x-4">
                    {/* Company Logo */}
                    <div className="flex-shrink-0">
                        <div className="w-16 h-16 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center overflow-hidden">
                            {companyLogo ? (
                                <img
                                    src={companyLogo}
                                    alt={company}
                                    className="w-full h-full object-cover"
                                />
                            ) : (
                                <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-accent-500 rounded-lg" />
                            )}
                        </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                        {/* Header */}
                        <div className="flex items-start justify-between mb-3">
                            <div>
                                <h3 className="text-xl font-semibold text-white group-hover:text-primary-300 transition-colors">
                                    {position}
                                </h3>
                                <p className="text-accent-400 font-medium">{company}</p>
                            </div>
                            <motion.button
                                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-primary-400 transition-colors"
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                            >
                                <FiExternalLink className="w-4 h-4" />
                            </motion.button>
                        </div>

                        {/* Meta Info */}
                        <div className="flex flex-wrap items-center gap-4 mb-4 text-sm text-neutral-400">
                            <div className="flex items-center space-x-2">
                                <FiCalendar className="w-4 h-4" />
                                <span>{period}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                                <FiMapPin className="w-4 h-4" />
                                <span>{location}</span>
                            </div>
                        </div>

                        {/* Description */}
                        <p className="text-neutral-300 leading-relaxed mb-4">
                            {description}
                        </p>

                        {/* Achievements */}
                        {achievements.length > 0 && (
                            <div className="mb-4">
                                <h4 className="text-sm font-semibold text-white mb-2">Key Achievements:</h4>
                                <ul className="space-y-1">
                                    {achievements.map((achievement, index) => (
                                        <li key={index} className="text-sm text-neutral-300 flex items-start space-x-2">
                                            <span className="text-primary-400 mt-1">•</span>
                                            <span>{achievement}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}

                        {/* Technologies */}
                        <div className="flex flex-wrap gap-2">
                            {technologies.map((tech, index) => (
                                <span
                                    key={tech}
                                    className="px-3 py-1 bg-white/10 rounded-full text-xs text-neutral-300 border border-white/20"
                                >
                                    {tech}
                                </span>
                            ))}
                        </div>
                    </div>
                </div>
            </GlassCard>
        </motion.div>
    );
};

export default ExperienceCard;
