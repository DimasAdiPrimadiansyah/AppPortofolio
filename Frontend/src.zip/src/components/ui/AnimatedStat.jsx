import React, { useEffect, useRef } from 'react';
import { motion, useMotionValue, useTransform, animate, useInView } from 'framer-motion';

// Jadikan icon menjadi prop opsional
const AnimatedStat = ({ number, suffix = '', label, icon: Icon }) => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.5 });

    const count = useMotionValue(0);
    const rounded = useTransform(count, latest => Math.round(latest));
    const numericValue = parseInt(String(number).replace(/,/g, ''), 10);

    useEffect(() => {
        if (isInView) {
            const controls = animate(count, numericValue, {
                duration: 2,
                ease: [0.16, 1, 0.3, 1],
            });
            return controls.stop;
        }
    }, [isInView, numericValue, count]);

    // Ini adalah desain baru yang lebih minimalis dan elegan
    return (
        <div ref={ref} className="text-left">
            {/* Render Ikon hanya jika prop 'icon' diberikan */}
            {Icon && (
                <div className="mb-2">
                    <Icon className="w-7 h-7 text-primary-400" />
                </div>
            )}
            <div className="flex items-baseline space-x-1">
                <motion.h3 className="text-4xl lg:text-5xl font-bold font-display text-white">
                    {rounded}
                </motion.h3>
                {suffix && (
                    <h3 className="text-3xl lg:text-4xl font-bold font-display text-primary-300">
                        {suffix}
                    </h3>
                )}
            </div>
            <p className="text-sm text-neutral-400 uppercase tracking-wider">
                {label}
            </p>
        </div>
    );
};

export default AnimatedStat;