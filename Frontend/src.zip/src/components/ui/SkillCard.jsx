import React from 'react';
import { motion } from 'framer-motion';
import GlassCard from './GlassCard';

const SkillCard = ({
    icon: Icon,
    title,
    level,
    description,
    technologies = [],
    color = 'text-primary-400',
    delay = 0
}) => {
    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay }}
            whileHover={{ y: -8, scale: 1.02 }}
            className="h-full"
        >
            <GlassCard className="p-6 h-full group cursor-pointer relative overflow-hidden" hover glow>
                {/* Background Gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary-500/5 to-accent-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                <div className="relative z-10">
                    {/* Icon Header */}
                    <div className="flex items-center justify-between mb-4">
                        <div className={`p-3 rounded-xl bg-white/10 ${color} group-hover:scale-110 transition-transform duration-300`}>
                            <Icon className="w-6 h-6" />
                        </div>
                        <div className={`text-2xl font-bold ${color}`}>
                            {level}%
                        </div>
                    </div>

                    {/* Title & Description */}
                    <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-primary-300 transition-colors">
                        {title}
                    </h3>
                    <p className="text-sm text-neutral-400 mb-4 leading-relaxed">
                        {description}
                    </p>

                    {/* Technologies */}
                    <div className="flex flex-wrap gap-2 mb-4">
                        {technologies.map((tech, index) => (
                            <span
                                key={tech}
                                className="px-2 py-1 bg-white/10 rounded-md text-xs text-neutral-300 border border-white/20"
                            >
                                {tech}
                            </span>
                        ))}
                    </div>

                    {/* Skill Level Bar */}
                    <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                            <span className="text-neutral-500">Proficiency</span>
                            <span className={color}>Expert</span>
                        </div>
                        <div className="w-full bg-white/10 rounded-full h-2">
                            <motion.div
                                className={`h-2 rounded-full bg-gradient-to-r from-primary-500 to-accent-500`}
                                initial={{ width: 0 }}
                                whileInView={{ width: `${level}%` }}
                                viewport={{ once: true }}
                                transition={{ duration: 1.5, delay: delay + 0.5, ease: "easeOut" }}
                            />
                        </div>
                    </div>
                </div>
            </GlassCard>
        </motion.div>
    );
};

export default SkillCard;
