import React from 'react';
import { motion } from 'framer-motion';
import GlassCard from './GlassCard';

const ValueCard = ({
    icon: Icon,
    title,
    description,
    color = 'text-primary-400',
    delay = 0
}) => {
    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay }}
            whileHover={{ y: -8, scale: 1.02 }}
        >
            <GlassCard className="p-8 text-center h-full group" hover>
                <motion.div
                    className={`inline-flex p-4 rounded-2xl bg-white/10 ${color} mb-6 group-hover:scale-110`}
                    transition={{ duration: 0.3 }}
                >
                    <Icon className="w-8 h-8" />
                </motion.div>

                <h3 className="text-xl font-semibold text-white mb-4">{title}</h3>
                <p className="text-neutral-300 leading-relaxed">{description}</p>
            </GlassCard>
        </motion.div>
    );
};

export default ValueCard;
