import React, { useState } from 'react';
import { motion } from 'framer-motion';
import GlassCard from './GlassCard';
import { FiExternalLink, FiGithub, FiImage, FiCalendar, FiCode } from 'react-icons/fi';

const ProjectCard = ({
    title = 'Untitled Project',
    category = 'Web Application',
    year = new Date().getFullYear(),
    status = 'planning',
    technologies = [],
    description = 'No description available',
    image,
    githubUrl,
    liveUrl,
    delay = 0
}) => {
    const [imageError, setImageError] = useState(false);
    const [imageLoading, setImageLoading] = useState(true);

    const getStatusColor = (status) => {
        if (!status || typeof status !== 'string') {
            return 'text-neutral-400 bg-neutral-400/20';
        }

        const normalizedStatus = status.toLowerCase().trim();

        switch (normalizedStatus) {
            case 'completed':
            case 'done':
            case 'finished':
                return 'text-green-400 bg-green-400/20';
            case 'in progress':
            case 'progress':
            case 'development':
            case 'ongoing':
                return 'text-yellow-400 bg-yellow-400/20';
            case 'planning':
            case 'planned':
            case 'design':
                return 'text-blue-400 bg-blue-400/20';
            case 'on hold':
            case 'paused':
                return 'text-orange-400 bg-orange-400/20';
            case 'cancelled':
            case 'canceled':
                return 'text-red-400 bg-red-400/20';
            default:
                return 'text-neutral-400 bg-neutral-400/20';
        }
    };

    const handleImageLoad = () => {
        setImageLoading(false);
    };

    const handleImageError = () => {
        setImageError(true);
        setImageLoading(false);
    };

    const formatStatus = (status) => {
        if (!status || typeof status !== 'string') return 'Unknown';
        return status.charAt(0).toUpperCase() + status.slice(1);
    };

    return (
        <motion.div
            initial={{ opacity: 0, y: 60, scale: 0.9 }}
            whileInView={{
                opacity: 1,
                y: 0,
                scale: 1,
                transition: {
                    duration: 0.8,
                    delay,
                    ease: [0.25, 0.46, 0.45, 0.94]
                }
            }}
            viewport={{ once: true, margin: "-50px" }}
            whileHover={{
                y: -12,
                scale: 1.03,
                transition: { duration: 0.3, ease: "easeOut" }
            }}
            className="h-full"
        >
            <GlassCard className="overflow-hidden group h-full flex flex-col relative" hover>
                {/* Parallax Background Effect */}
                <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-primary-500/5 to-accent-500/5 opacity-0 group-hover:opacity-100"
                    initial={false}
                    animate={{
                        background: [
                            "linear-gradient(135deg, rgba(59, 130, 246, 0.05) 0%, rgba(217, 70, 239, 0.05) 100%)",
                            "linear-gradient(135deg, rgba(217, 70, 239, 0.05) 0%, rgba(59, 130, 246, 0.05) 100%)"
                        ]
                    }}
                    transition={{ duration: 3, repeat: Infinity, repeatType: "reverse" }}
                />

                {/* Project Image */}
                <motion.div
                    className="relative group"
                    whileHover={{ scale: 1.05, boxShadow: "0 10px 20px rgba(0, 0, 0, 0.2)" }}
                    transition={{ duration: 0.3 }}
                >
                    {image && !imageError ? (
                        <>
                            {imageLoading && (
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <motion.div
                                        className="w-8 h-8 border-2 border-primary-400 border-t-transparent rounded-full"
                                        animate={{ rotate: 360 }}
                                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                                    />
                                </div>
                            )}
                            <motion.img
                                src={image}
                                alt={title}
                                className={`w-full h-full object-cover ${imageLoading ? 'opacity-0' : 'opacity-100'}`}
                                onLoad={handleImageLoad}
                                onError={handleImageError}
                                whileHover={{ scale: 1.1 }}
                                transition={{ duration: 0.6, ease: "easeOut" }}
                            />
                        </>
                    ) : (
                        <motion.div
                            className="w-full h-full flex items-center justify-center"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.3 }}
                        >
                            <div className="text-center">
                                <motion.div
                                    animate={{
                                        y: [0, -10, 0],
                                        rotate: [0, 5, -5, 0]
                                    }}
                                    transition={{
                                        duration: 2,
                                        repeat: Infinity,
                                        ease: "easeInOut"
                                    }}
                                >
                                    <FiImage className="w-16 h-16 text-neutral-600 mx-auto mb-2" />
                                </motion.div>
                                <p className="text-xs text-neutral-500">No Image</p>
                            </div>
                        </motion.div>
                    )}

                    {/* Status Badge with Animation */}
                    <motion.div
                        className="absolute top-4 right-4"
                        initial={{ opacity: 0, x: 20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ delay: delay + 0.3 }}
                    >
                        <motion.span
                            className={`px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm ${getStatusColor(status)}`}
                            whileHover={{ scale: 1.1 }}
                            transition={{ duration: 0.2 }}
                        >
                            {formatStatus(status)}
                        </motion.span>
                    </motion.div>

                    {/* Overlay on Hover with Staggered Animation */}
                    <motion.div
                        className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center space-x-4"
                        initial={false}
                    >
                        {githubUrl && (
                            <motion.a
                                href={githubUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-3 bg-white/20 backdrop-blur-sm rounded-full text-white hover:bg-white/30 transition-colors"
                                initial={{ scale: 0, rotate: -180 }}
                                whileInView={{ scale: 1, rotate: 0 }}
                                whileHover={{ scale: 1.2, rotate: 5 }}
                                whileTap={{ scale: 0.9 }}
                                transition={{
                                    delay: delay + 0.4,
                                    type: "spring",
                                    stiffness: 200
                                }}
                                aria-label="View on GitHub"
                            >
                                <FiGithub className="w-5 h-5" />
                            </motion.a>
                        )}
                        {liveUrl && (
                            <motion.a
                                href={liveUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-3 bg-white/20 backdrop-blur-sm rounded-full text-white hover:bg-white/30 transition-colors"
                                initial={{ scale: 0, rotate: 180 }}
                                whileInView={{ scale: 1, rotate: 0 }}
                                whileHover={{ scale: 1.2, rotate: -5 }}
                                whileTap={{ scale: 0.9 }}
                                transition={{
                                    delay: delay + 0.5,
                                    type: "spring",
                                    stiffness: 200
                                }}
                                aria-label="View Live Demo"
                            >
                                <FiExternalLink className="w-5 h-5" />
                            </motion.a>
                        )}
                    </motion.div>
                </motion.div>

                {/* Project Info with Staggered Animations */}
                <div className="p-6 flex-1 flex flex-col relative z-10">
                    {/* Title & Category */}
                    <motion.div
                        className="mb-4"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: delay + 0.2 }}
                    >
                        <motion.h3
                            className="text-xl font-bold text-white mb-2 group-hover:text-primary-300 transition-colors line-clamp-2"
                            whileHover={{ x: 5 }}
                            transition={{ duration: 0.2 }}
                        >
                            {title}
                        </motion.h3>
                        <motion.p
                            className="text-sm text-accent-400 font-medium"
                            initial={{ opacity: 0 }}
                            whileInView={{ opacity: 1 }}
                            transition={{ delay: delay + 0.3 }}
                        >
                            {category}
                        </motion.p>
                    </motion.div>

                    {/* Project Details */}
                    <motion.div
                        className="space-y-2 mb-4 text-sm"
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ delay: delay + 0.4 }}
                    >
                        <div className="flex items-center justify-between">
                            <span className="text-neutral-500 flex items-center space-x-1">
                                <FiCalendar className="w-3 h-3" />
                                <span>Year:</span>
                            </span>
                            <span className="text-neutral-300">{year}</span>
                        </div>
                        <div className="flex items-center justify-between">
                            <span className="text-neutral-500">Status:</span>
                            <span className={`${getStatusColor(status).split(' ')[0]} font-medium`}>
                                {formatStatus(status)}
                            </span>
                        </div>
                    </motion.div>

                    {/* Description */}
                    <motion.p
                        className="text-neutral-400 text-sm leading-relaxed mb-4 flex-1 line-clamp-3"
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        transition={{ delay: delay + 0.5 }}
                    >
                        {description}
                    </motion.p>

                    {/* Technologies with Staggered Animation */}
                    <motion.div
                        className="mb-6"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: delay + 0.6 }}
                    >
                        <div className="flex flex-wrap gap-2">
                            {technologies.slice(0, 4).map((tech, index) => (
                                <motion.span
                                    key={`${tech}-${index}`}
                                    className="px-2 py-1 bg-white/10 rounded-md text-xs text-neutral-300 border border-white/20"
                                    initial={{ opacity: 0, scale: 0.8 }}
                                    whileInView={{ opacity: 1, scale: 1 }}
                                    whileHover={{ scale: 1.1, y: -2 }}
                                    transition={{
                                        delay: delay + 0.7 + (index * 0.1),
                                        duration: 0.3
                                    }}
                                >
                                    {tech}
                                </motion.span>
                            ))}
                            {technologies.length > 4 && (
                                <motion.span
                                    className="px-2 py-1 bg-white/10 rounded-md text-xs text-neutral-400 border border-white/20"
                                    initial={{ opacity: 0, scale: 0.8 }}
                                    whileInView={{ opacity: 1, scale: 1 }}
                                    transition={{ delay: delay + 1.1 }}
                                >
                                    +{technologies.length - 4} more
                                </motion.span>
                            )}
                        </div>
                    </motion.div>
                </div>
            </GlassCard>
        </motion.div>
    );
};

export default ProjectCard;
