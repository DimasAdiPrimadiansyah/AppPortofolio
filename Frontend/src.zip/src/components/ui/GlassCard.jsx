import React from 'react';
import { motion } from 'framer-motion';

const GlassCard = ({
    children,
    className = '',
    hover = false,
    glow = false,
    ...props
}) => {
    const baseClasses = `
        bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl
        ${glow ? 'shadow-2xl shadow-primary-500/10' : 'shadow-xl'}
        ${className}
    `;

    const hoverClasses = hover ? `
        hover:bg-white/10 hover:border-white/20 hover:shadow-2xl 
        hover:shadow-primary-500/20 transition-all duration-300
    ` : '';

    if (hover) {
        return (
            <motion.div
                className={`${baseClasses} ${hoverClasses}`}
                whileHover={{ y: -2 }}
                transition={{ duration: 0.2 }}
                {...props}
            >
                {children}
            </motion.div>
        );
    }

    return (
        <div className={baseClasses} {...props}>
            {children}
        </div>
    );
};

export default GlassCard;
