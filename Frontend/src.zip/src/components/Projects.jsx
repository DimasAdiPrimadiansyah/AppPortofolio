import { motion } from 'framer-motion';
import Section from './layout/Section';
import Container from './layout/Container';
import ProjectCard from './ui/ProjectCard';
import { useState } from 'react';

// Hardcoded Projects Data
const projectsData = [
    {
        id: 1,
        title: 'E-Commerce Platform',
        category: 'Web Application',
        year: 2023,
        status: 'completed',
        technologies: ['React', 'Node.js', 'MongoDB', 'Stripe', 'Tailwind CSS', 'Redux'],
        description: 'Full-featured e-commerce platform with payment integration, user authentication, admin dashboard, and real-time inventory management.',
        image: null,
        githubUrl: 'https://github.com/username/ecommerce',
        liveUrl: 'https://ecommerce-demo.com'
    },
    {
        id: 2,
        title: 'Task Management App',
        category: 'Mobile Application',
        year: 2023,
        status: 'in progress',
        technologies: ['React Native', 'Firebase', 'Redux', 'Expo', 'TypeScript'],
        description: 'Cross-platform mobile app for team task management with real-time collaboration, push notifications, and offline support.',
        image: null,
        githubUrl: 'https://github.com/username/taskapp',
        liveUrl: null
    },
    {
        id: 3,
        title: 'Portfolio Website',
        category: 'Web Application',
        year: 2023,
        status: 'completed',
        technologies: ['Next.js', 'TypeScript', 'Framer Motion', 'Tailwind CSS'],
        description: 'Modern portfolio website with smooth animations, responsive design, and optimized performance for showcasing projects.',
        image: null,
        githubUrl: 'https://github.com/username/portfolio',
        liveUrl: 'https://portfolio-demo.com'
    },
    {
        id: 4,
        title: 'Weather Dashboard',
        category: 'Web Application',
        year: 2022,
        status: 'completed',
        technologies: ['Vue.js', 'Chart.js', 'OpenWeather API', 'Vuex'],
        description: 'Interactive weather dashboard with data visualization, location-based forecasts, and historical weather data analysis.',
        image: null,
        githubUrl: 'https://github.com/username/weather-dashboard',
        liveUrl: 'https://weather-dashboard-demo.com'
    },
    {
        id: 5,
        title: 'Social Media Analytics',
        category: 'Web Application',
        year: 2022,
        status: 'completed',
        technologies: ['React', 'D3.js', 'Node.js', 'PostgreSQL', 'Socket.io'],
        description: 'Comprehensive social media analytics platform with real-time data processing and interactive visualizations.',
        image: null,
        githubUrl: 'https://github.com/username/social-analytics',
        liveUrl: 'https://analytics-demo.com'
    },
    {
        id: 6,
        title: 'Learning Management System',
        category: 'Web Application',
        year: 2021,
        status: 'completed',
        technologies: ['Laravel', 'Vue.js', 'MySQL', 'WebRTC', 'AWS S3'],
        description: 'Complete LMS with video conferencing, assignment management, progress tracking, and interactive learning modules.',
        image: null,
        githubUrl: 'https://github.com/username/lms',
        liveUrl: 'https://lms-demo.com'
    }
];

const Projects = () => {
    const [filter, setFilter] = useState('all');
    const [viewMode, setViewMode] = useState('grid');

    const categories = ['all', 'web', 'mobile', 'desktop'];

    const filteredProjects = filter === 'all'
        ? projectsData
        : projectsData.filter(project =>
            project.category.toLowerCase().includes(filter)
        );

    // Container variants for staggered animations
    const containerVariants = {
        hidden: { opacity: 0, scale: 0.98, filter: 'blur(8px)' },
        visible: {
            opacity: 1,
            scale: 1,
            filter: 'blur(0px)',
            transition: {
                staggerChildren: 0.15,
                delayChildren: 0.3,
                duration: 1,
                ease: [0.4, 2, 0.6, 1],
            },
        },
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 40, scale: 0.95, filter: 'blur(8px)' },
        visible: {
            opacity: 1,
            y: 0,
            scale: 1,
            filter: 'blur(0px)',
            transition: { duration: 0.7, ease: [0.4, 2, 0.6, 1] },
        },
    };

    return (
        <Section id="projects" className="relative bg-gradient-to-br from-neutral-900 via-neutral-950 to-black py-20 overflow-hidden">
            {/* Animated Background */}
            <motion.div
                className="absolute inset-0 opacity-10 pointer-events-none"
                animate={{
                    background: [
                        "radial-gradient(circle at 20% 50%, #38bdf8 0%, transparent 60%)",
                        "radial-gradient(circle at 80% 50%, #818cf8 0%, transparent 60%)"
                    ]
                }}
                transition={{ duration: 8, repeat: Infinity, repeatType: "reverse" }}
            />
            <Container>
                {/* Header */}
                <motion.div
                    className="text-center mb-16"
                    initial={{ opacity: 0, y: 40, scale: 0.95 }}
                    whileInView={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ duration: 1, ease: [0.4, 2, 0.6, 1] }}
                    viewport={{ once: true }}
                >
                    <h2 className="text-4xl lg:text-6xl font-display font-bold text-white mb-6">
                        Featured Projects
                    </h2>
                    <p className="text-lg text-neutral-400 max-w-3xl mx-auto leading-relaxed">
                        Koleksi project terbaik yang telah saya kerjakan dengan berbagai teknologi modern dan inovatif
                    </p>
                </motion.div>

                {/* Projects Grid */}
                <motion.div
                    className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
                    variants={containerVariants}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, margin: "-100px" }}
                >
                    {filteredProjects.map((project, index) => (
                        <motion.div
                            key={project.id}
                            variants={itemVariants}
                        >
                            <ProjectCard {...project} delay={index * 0.1} />
                        </motion.div>
                    ))}
                </motion.div>
            </Container>
        </Section>
    );
};

export default Projects;
