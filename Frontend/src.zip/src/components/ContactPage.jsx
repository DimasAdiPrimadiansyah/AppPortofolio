import React from 'react';
import Section from './layout/Section';
import Container from './layout/Container';
import { FiMapPin, FiMail, FiPhone } from 'react-icons/fi';

const contactInfo = [
    { icon: FiMapPin, label: 'Jakarta, Indonesia' },
    { icon: FiMail, label: 'dimas@example.com' },
    { icon: FiPhone, label: '+62 812 3456 7890' },
];

const ContactPage = () => {
    return (
        <Section id="contact" className="bg-neutral-900 text-white py-10">
            <Container>
                <h1 className="text-4xl font-bold text-center mb-8">Contact</h1>
                <div className="flex flex-col items-center">
                    {contactInfo.map((info, index) => (
                        <div key={index} className="flex items-center space-x-2 mb-4">
                            <info.icon className="w-6 h-6 text-primary-400" />
                            <span className="text-lg text-neutral-300">{info.label}</span>
                        </div>
                    ))}
                </div>
            </Container>
        </Section>
    );
};

export default ContactPage;
