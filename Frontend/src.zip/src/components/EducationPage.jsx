import React from 'react';
import { motion } from 'framer-motion';
import Section from './layout/Section';
import Container from './layout/Container';
import AnimatedText from './ui/AnimatedText';
import { FaGraduationCap } from 'react-icons/fa';

const educationData = [
    {
        degree: 'S1 Teknik Informatika',
        institution: 'Universitas Pamulang',
        year: '2022 - Saat ini',
    },
    {
        degree: 'Teknik Mesin',
        institution: 'SMK Mekanika Bogor',
        year: '2016 - 2019',
    },
];

const EducationCard = ({ degree, institution, year }) => (
    <motion.div
        className="bg-neutral-800 border border-neutral-700 rounded-lg p-6 flex items-center space-x-4 shadow-md transition-transform transform hover:scale-105"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
    >
        <FaGraduationCap className="w-8 h-8 text-primary-400" />
        <div>
            <h3 className="text-xl font-semibold text-white">{degree}</h3>
            <p className="text-lg text-neutral-300">{institution}</p>
            <p className="text-sm text-neutral-400">{year}</p>
        </div>
    </motion.div>
);

const EducationPage = () => (
    <Section id="education" className="bg-neutral-900 text-white py-10 relative overflow-hidden">
        {/* Animated Background */}
        <motion.div
            className="absolute inset-0 opacity-10 pointer-events-none"
            animate={{
                background: [
                    "radial-gradient(circle at 60% 40%, #38bdf8 0%, transparent 60%)",
                    "radial-gradient(circle at 40% 60%, #818cf8 0%, transparent 60%)"
                ]
            }}
            transition={{ duration: 10, repeat: Infinity, repeatType: "reverse" }}
        />
        <Container>
            <AnimatedText
                text="Education"
                className="text-4xl font-bold text-center mb-8"
                variant="fadeIn"
            />
            <div className="space-y-6">
                {educationData.map((edu, index) => (
                    <EducationCard key={index} {...edu} />
                ))}
            </div>
        </Container>
    </Section>
);

export default EducationPage;