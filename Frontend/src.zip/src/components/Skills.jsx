// src/components/Skills.jsx
import React, { useState, useRef, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import SkillsIntroScroll from './SkillsIntroScroll';
import SkillsContent from './SkillsContent';
import Section from './layout/Section';

const Skills = ({ active }) => {
    const [stage, setStage] = useState('intro');
    const [showContent, setShowContent] = useState(false);
    const contentRef = useRef(null);

    // Reset animasi setiap kali section Skills diakses
    useEffect(() => {
        setStage('intro');
        setShowContent(false);
    }, [active]); // pastikan 'active' berubah saat user ke section Skills

    const handleIntroComplete = () => {
        setStage('outro');
        setTimeout(() => {
            setShowContent(true);
            setStage('content');
        }, 600);
    };

    useEffect(() => {
        if (stage === 'content' && contentRef.current) {
            contentRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, [stage]);

    return (
        <Section ref={contentRef} id="skills" className="relative bg-neutral-900 pt-0">
            <AnimatePresence mode="wait">
                {stage === 'intro' && (
                    <motion.div
                        key="skills-intro"
                        initial={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
                        animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
                        exit={{
                            opacity: 0,
                            scale: 1.08,
                            filter: 'blur(16px)',
                            transition: { duration: 0.9, ease: [0.4, 2, 0.6, 1] }
                        }}
                    >
                        <SkillsIntroScroll onComplete={handleIntroComplete} />
                    </motion.div>
                )}

                {showContent && stage === 'content' && (
                    <motion.div
                        key="skills-content"
                        initial={{ opacity: 0, y: 80, scale: 0.96, filter: 'blur(12px)' }}
                        animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
                        transition={{ duration: 1, ease: [0.4, 2, 0.6, 1] }}
                    >
                        <SkillsContent />
                    </motion.div>
                )}
            </AnimatePresence>
        </Section>
    );
};

export default Skills;