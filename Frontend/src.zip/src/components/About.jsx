import React, { forwardRef } from 'react';
import { motion } from 'framer-motion';
import Section from './layout/Section';
import Container from './layout/Container';
import GlassCard from './ui/GlassCard';
import AnimatedText from './ui/AnimatedText';
import ValueCard from './ui/ValueCard';
import {
    FiCode,
    FiUsers,
    FiTrendingUp,
    FiBriefcase,
    FiHeart,
    FiTarget,
    FiZap,
    FiAward,
    FiDownload,
    FiMail
} from 'react-icons/fi';

// --- Data (tidak berubah) ---
const aboutStats = [
    { icon: FiCode, number: '3+', label: 'Years Experience', color: 'text-primary-400' },
    { icon: FiBriefcase, number: '50+', label: 'Projects Completed', color: 'text-accent-400' },
    { icon: FiUsers, number: '20+', label: 'Happy Clients', color: 'text-green-400' },
    { icon: FiTrendingUp, number: '100%', label: 'Success Rate', color: 'text-blue-400' }
];

const values = [
    {
        icon: FiHeart,
        title: 'Passion-Driven',
        description: 'Saya percaya bahwa passion adalah kunci untuk menciptakan solusi yang luar biasa dan bermakna.',
        color: 'text-red-400'
    },
    {
        icon: FiTarget,
        title: 'Goal-Oriented',
        description: 'Setiap project dimulai dengan tujuan yang jelas dan roadmap yang terstruktur untuk mencapai hasil optimal.',
        color: 'text-blue-400'
    },
    {
        icon: FiZap,
        title: 'Innovation First',
        description: 'Selalu mencari cara baru dan teknologi terdepan untuk memberikan solusi yang efisien dan modern.',
        color: 'text-yellow-400'
    },
    {
        icon: FiAward,
        title: 'Quality Focus',
        description: 'Kualitas adalah prioritas utama - dari clean code hingga user experience yang exceptional.',
        color: 'text-green-400'
    }
];

// --- Komponen Utama ---
const About = forwardRef((props, ref) => {
    return (
        // Container terluar yang menerima ref dan id dari App.jsx
        // React Fragment <> diganti dengan <div> agar bisa menerima props
        <div id="about" ref={ref}>
            {/* Hero About Section */}
            <Section className="relative overflow-hidden" background="glass">
                <Container>
                    <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
                        {/* Content */}
                        <motion.div
                            initial={{ opacity: 0, x: -50 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true, amount: 0.3 }}
                            transition={{ duration: 0.8 }}
                            className="space-y-8"
                        >
                            <div>
                                <AnimatedText
                                    text="About Me"
                                    className="text-4xl lg:text-6xl font-display font-bold text-white mb-6"
                                    variant="fadeUp"
                                />

                                <AnimatedText
                                    text="Saya adalah seorang Full-Stack Developer yang passionate dalam menciptakan solusi digital inovatif. Dengan pengalaman lebih dari 3 tahun, saya fokus pada pengembangan aplikasi web modern yang user-friendly dan performant."
                                    className="text-lg text-neutral-300 leading-relaxed mb-6"
                                    variant="fadeUp"
                                    delay={0.2}
                                />

                                <AnimatedText
                                    text="Saya percaya bahwa teknologi terbaik adalah yang dapat memecahkan masalah nyata dan memberikan value kepada pengguna. Setiap project yang saya kerjakan selalu dimulai dengan memahami kebutuhan user dan business goals."
                                    className="text-lg text-neutral-300 leading-relaxed mb-8"
                                    variant="fadeUp"
                                    delay={0.4}
                                />

                                {/* Action Buttons */}
                                <motion.div
                                    className="flex flex-col sm:flex-row gap-4"
                                    initial={{ opacity: 0, y: 20 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true, amount: 0.3 }}
                                    transition={{ delay: 0.6 }}
                                >
                                    <motion.button
                                        className="px-8 py-4 bg-gradient-to-r from-primary-600 to-accent-600 rounded-2xl font-semibold text-white hover:from-primary-500 hover:to-accent-500 transition-all duration-300 flex items-center justify-center space-x-2"
                                        whileHover={{ scale: 1.05 }}
                                        whileTap={{ scale: 0.95 }}
                                    >
                                        <FiDownload className="w-4 h-4" />
                                        <span>Download CV</span>
                                    </motion.button>

                                    <motion.button
                                        className="px-8 py-4 border-2 border-white/20 rounded-2xl font-semibold text-white hover:bg-white/5 hover:border-primary-400 transition-all duration-300 flex items-center justify-center space-x-2"
                                        whileHover={{ scale: 1.05 }}
                                        whileTap={{ scale: 0.95 }}
                                    >
                                        <FiMail className="w-4 h-4" />
                                        <span>Get In Touch</span>
                                    </motion.button>
                                </motion.div>
                            </div>
                        </motion.div>

                        {/* Stats Cards */}
                        <motion.div
                            initial={{ opacity: 0, x: 50 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true, amount: 0.3 }}
                            transition={{ duration: 0.8 }}
                            className="grid grid-cols-2 gap-6"
                        >
                            {aboutStats.map((stat, index) => (
                                <motion.div
                                    key={stat.label}
                                    initial={{ opacity: 0, y: 20 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true, amount: 0.3 }}
                                    transition={{ delay: 0.2 + index * 0.1 }}
                                    whileHover={{ y: -5, scale: 1.02 }}
                                >
                                    <GlassCard className="text-center p-6" hover glow>
                                        <div className={`inline-flex p-3 rounded-xl bg-white/10 ${stat.color} mb-4`}>
                                            <stat.icon className="w-6 h-6" />
                                        </div>
                                        <div className={`text-2xl lg:text-3xl font-bold ${stat.color} mb-2`}>
                                            {stat.number}
                                        </div>
                                        <div className="text-sm text-neutral-400">
                                            {stat.label}
                                        </div>
                                    </GlassCard>
                                </motion.div>
                            ))}
                        </motion.div>
                    </div>
                </Container>
            </Section>

            {/* Values & Philosophy */}
            <Section>
                <Container>
                    <div className="text-center mb-16">
                        <AnimatedText
                            text="Core Values"
                            className="text-4xl lg:text-5xl font-display font-bold text-white mb-6"
                            variant="fadeUp"
                        />
                        <AnimatedText
                            text="Prinsip-prinsip yang memandu setiap project dan kolaborasi yang saya lakukan"
                            className="text-lg text-neutral-400 max-w-2xl mx-auto"
                            variant="fadeUp"
                            delay={0.2}
                        />
                    </div>

                    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                        {values.map((value, index) => (
                            <ValueCard
                                key={value.title}
                                {...value}
                                delay={index * 0.1}
                            />
                        ))}
                    </div>
                </Container>
            </Section>
        </div>
    );
});

export default About;