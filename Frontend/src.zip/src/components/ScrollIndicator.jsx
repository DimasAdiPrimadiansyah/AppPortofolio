import React from 'react';
import { motion } from 'framer-motion';

const ScrollIndicator = () => {
    return (
        <motion.div
            className="fixed bottom-10 left-1/2 transform -translate-x-1/2 flex flex-col items-center cursor-pointer select-none"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ repeat: Infinity, repeatType: 'reverse', duration: 1.5 }}
        >
            <div className="w-10 h-16 border-2 border-gray-400 rounded-full flex justify-center items-start p-1">
                <motion.div
                    className="w-2 h-2 bg-gray-400 rounded-full"
                    animate={{ y: [0, 10, 0] }}
                    transition={{ repeat: Infinity, duration: 1.5 }}
                />
            </div>
            <span className="mt-2 text-gray-400 text-sm font-light">Scroll Down</span>
        </motion.div>
    );
};

export default ScrollIndicator;
