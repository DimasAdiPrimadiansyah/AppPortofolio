// src/components/ProfileIntroScroll.jsx
import React, { useEffect, useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

const ProfileIntroScroll = ({ onScrollDone }) => {
    const scrollRef = useRef(null);
    const { scrollYProgress } = useScroll({ container: scrollRef });

    // Transformasi cinematic
    const scale = useTransform(scrollYProgress, [0, 1], [1, 1.2]);
    const opacity = useTransform(scrollYProgress, [0, 0.8, 1], [1, 0.7, 0]);

    // Kata per kata movement
    const xLeft = useTransform(scrollYProgress, [0, 1], [0, -window.innerWidth * 0.3]);
    const yUp = useTransform(scrollYProgress, [0, 1], [0, -window.innerHeight * 0.3]);
    const xRight = useTransform(scrollYProgress, [0, 1], [0, window.innerWidth * 0.3]);

    // Trigger lanjut jika scroll selesai
    useEffect(() => {
        const unsub = scrollYProgress.on("change", (v) => {
            if (v >= 0.99) {
                document.body.style.overflow = 'auto';
                onScrollDone();
            }
        });
        return () => unsub();
    }, [scrollYProgress, onScrollDone]);

    // Reset scroll dan lock saat awal
    useEffect(() => {
        const prev = document.body.style.overflow;
        document.body.style.overflow = 'hidden';

        requestAnimationFrame(() => {
            if (scrollRef.current) {
                scrollRef.current.scrollTop = 0;
            }
        });

        return () => {
            document.body.style.overflow = prev;
        };
    }, []);

    return (
        <div className="fixed inset-0 bg-black z-[100] overflow-hidden">
            {/* Konten cinematic */}
            <motion.div
                className="absolute inset-0 flex items-center justify-center"
                style={{ scale, opacity }}
            >
                <motion.div
                    className="flex items-center gap-6 text-white text-4xl md:text-6xl font-medium tracking-wide"
                    style={{
                        fontFamily: '"Cormorant Garamond", serif',
                        transform: 'translateY(-10%)',
                    }}
                >
                    <motion.span style={{ x: xLeft }}>Dimas</motion.span>
                    <motion.span style={{ y: yUp }}>Adi</motion.span>
                    <motion.span style={{ x: xRight }}>Primadiansyah</motion.span>
                </motion.div>
            </motion.div>

            {/* Scroll Guide */}
            <div className="absolute bottom-24 left-1/2 transform -translate-x-1/2 flex flex-col items-center text-white/80">
                <motion.div
                    className="w-6 h-10 border-2 border-white rounded-full flex items-center justify-center"
                    animate={{ y: [0, 6, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                >
                    <div className="w-1 h-2 bg-white rounded-full" />
                </motion.div>
                <p className="mt-2 text-sm uppercase tracking-widest">Scroll down</p>
            </div>

            {/* Scrollable area */}
            <div ref={scrollRef} className="absolute inset-0 overflow-y-scroll z-20">
                <div className="h-[300vh]" />
            </div>
        </div>
    );
};

export default ProfileIntroScroll;
