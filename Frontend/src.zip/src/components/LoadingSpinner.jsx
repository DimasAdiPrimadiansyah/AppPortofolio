import React from 'react';
import { motion } from 'framer-motion';

const LoadingSpinner = () => {
    return (
        <motion.div
            className="w-16 h-16 border-4 border-primary-400 border-t-transparent rounded-full animate-spin"
            initial={{ rotate: 0 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity }}
        />
    );
};

export default LoadingSpinner;
