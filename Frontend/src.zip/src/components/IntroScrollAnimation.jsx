// src/components/IntroScrollAnimation.jsx
import React, { useEffect } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

const IntroScrollAnimation = ({ onDone }) => {
    const { scrollYProgress } = useScroll();

    // Transisi scroll ke pathLength (hanya dari 0 hingga 100vh pertama)
    const pathLength = useTransform(scrollYProgress, [0, 0.2], [0, 1]);

    useEffect(() => {
        const unsubscribe = pathLength.on('change', (v) => {
            if (v >= 1) {
                onDone();
            }
        });
        return () => unsubscribe();
    }, [pathLength, onDone]);

    return (
        <div className="fixed inset-0 z-50 bg-neutral-900 flex flex-col items-center justify-center">
            <svg width="160" height="200" viewBox="0 0 160 200" fill="none">
                <motion.path
                    d="M10 10 C 80 100, 80 100, 150 190"
                    stroke="#ccc"
                    strokeWidth="3"
                    fill="none"
                    style={{ pathLength }}
                />
            </svg>
            <motion.div
                className="mt-6 flex items-center text-white space-x-2"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
            >
                <span>Scroll</span>
                <motion.div className="w-6 h-10 border-2 border-white rounded-full flex items-center justify-center">
                    <motion.div
                        className="w-1 h-1 bg-white rounded-full"
                        animate={{ y: [2, 8, 2] }}
                        transition={{ duration: 1, repeat: Infinity }}
                    />
                </motion.div>
                <span>Down</span>
            </motion.div>
        </div>
    );
};

export default IntroScrollAnimation;
