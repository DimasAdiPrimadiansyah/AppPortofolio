// src/components/SkillsContent.jsx
import React from 'react';
import { motion } from 'framer-motion';
import skillsData from '../data/skillsData'; // pastikan data Anda sudah benar

const containerVariants = {
    hidden: { opacity: 0, scale: 0.98, filter: 'blur(8px)' },
    visible: {
        opacity: 1,
        scale: 1,
        filter: 'blur(0px)',
        transition: {
            staggerChildren: 0.18,
            delayChildren: 0.3,
            duration: 1,
            ease: [0.4, 2, 0.6, 1],
        },
    },
};

const cardVariants = {
    hidden: { y: 60, opacity: 0, scale: 0.95, filter: 'blur(8px)' },
    visible: {
        y: 0,
        opacity: 1,
        scale: 1,
        filter: 'blur(0px)',
        transition: {
            duration: 0.7,
            ease: [0.4, 2, 0.6, 1],
        },
    },
};

const headerVariants = {
    hidden: { y: -40, opacity: 0, scale: 0.95, filter: 'blur(8px)' },
    visible: {
        y: 0,
        opacity: 1,
        scale: 1,
        filter: 'blur(0px)',
        transition: {
            duration: 1,
            ease: [0.4, 2, 0.6, 1],
        },
    },
};

const SkillsContent = () => {
    return (
        <motion.div
            className="w-full min-h-screen flex flex-col justify-center items-center px-4 py-12 bg-gradient-to-br from-neutral-900 via-neutral-950 to-black"
            initial="hidden"
            animate="visible"
            variants={containerVariants}
        >
            <div className="max-w-6xl w-full mx-auto">
                <motion.div
                    className="text-center mb-12"
                    variants={headerVariants}
                >
                    <h2 className="text-5xl md:text-6xl font-bold font-display text-white mb-4 drop-shadow-xl">
                        My Core Expertise
                    </h2>
                    <p className="text-xl text-neutral-300 max-w-2xl mx-auto">
                        The primary technologies I wield to build performant and elegant applications
                        across different platforms and environments.
                    </p>
                </motion.div>

                <motion.div
                    className="grid grid-cols-1 md:grid-cols-2 gap-8"
                    variants={containerVariants}
                >
                    {skillsData.map((skill, index) => (
                        <motion.div
                            key={skill.category}
                            className="group relative bg-neutral-800/60 backdrop-blur-lg border border-neutral-700/60 rounded-2xl p-8 hover:bg-neutral-800/80 transition-all duration-500 shadow-2xl"
                            variants={cardVariants}
                            whileHover={{
                                y: -16,
                                scale: 1.04,
                                boxShadow: `0 8px 40px 0 var(--tw-shadow-color)`,
                                transition: { duration: 0.4 }
                            }}
                        >
                            {/* Animated badge */}
                            <motion.div
                                className="absolute top-6 right-6 px-4 py-1 rounded-full bg-gradient-to-r from-primary-500/20 to-accent-500/20 text-primary-300 font-bold text-xs shadow-lg"
                                initial={{ opacity: 0, scale: 0.8, y: -10 }}
                                animate={{ opacity: 1, scale: 1, y: 0 }}
                                transition={{ delay: 0.2 + index * 0.1, duration: 0.5, type: "spring" }}
                            >
                                {skill.category}
                            </motion.div>

                            {/* Gradient overlay */}
                            <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-br from-${skill.color}-500/20 via-transparent to-transparent`} />

                            {/* Glow effect */}
                            <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 shadow-2xl shadow-${skill.color}-500/30`} />

                            <div className="relative z-10">
                                <div className="flex items-center gap-4 mb-4">
                                    <motion.div
                                        className={`p-4 rounded-xl bg-${skill.color}-500/20 border border-${skill.color}-500/30`}
                                        whileHover={{ scale: 1.15 }}
                                        transition={{ duration: 0.3 }}
                                    >
                                        <span className={`text-3xl text-${skill.color}-400`}>
                                            {skill.icon}
                                        </span>
                                    </motion.div>
                                    <h3 className="text-2xl font-semibold text-white">
                                        {skill.category}
                                    </h3>
                                </div>

                                <p className="text-neutral-300 text-lg mb-6 leading-relaxed">
                                    {skill.description}
                                </p>

                                <div className="flex flex-wrap gap-3">
                                    {skill.technologies.map((tech, techIndex) => (
                                        <motion.div
                                            key={tech.name}
                                            className="flex items-center gap-2 px-4 py-2 bg-neutral-900/70 border border-neutral-600/60 rounded-xl text-base hover:bg-neutral-900/90 transition-colors duration-300"
                                            whileHover={{ scale: 1.08 }}
                                            initial={{ opacity: 0, scale: 0.9, filter: 'blur(6px)' }}
                                            animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
                                            transition={{
                                                delay: 0.12 * techIndex,
                                                duration: 0.4
                                            }}
                                        >
                                            <span className={`text-xl ${tech.color}`}>
                                                {tech.icon}
                                            </span>
                                            <span className="font-medium text-neutral-100">
                                                {tech.name}
                                            </span>
                                        </motion.div>
                                    ))}
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </motion.div>

                <motion.div
                    className="text-center mt-16"
                    variants={headerVariants}
                >
                    <p className="text-neutral-400 text-lg">
                        Always learning and exploring new technologies to stay at the forefront of development.
                    </p>
                </motion.div>
            </div>
        </motion.div>
    );
};

export default SkillsContent;