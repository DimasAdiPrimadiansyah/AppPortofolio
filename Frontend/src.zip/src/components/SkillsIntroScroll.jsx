import React, { useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, useInView } from 'framer-motion';

const SkillsIntroScroll = ({ onComplete }) => {
    const triggerRef = useRef(null);
    const scrollRef = useRef(null);
    const isInView = useInView(triggerRef, { once: true, amount: 0.5 });
    const { scrollYProgress } = useScroll({ container: scrollRef });

    // Event selesai scroll penuh
    useEffect(() => {
        const unsub = scrollYProgress.on("change", (v) => {
            if (v >= 1) {
                scrollYProgress.clearListeners();
                document.body.style.overflow = 'auto';
                onComplete();
            }
        });
        return () => unsub();
    }, [scrollYProgress, onComplete]);

    // Lock scroll saat animasi intro aktif
    useEffect(() => {
        if (isInView) document.body.style.overflow = 'hidden';
        return () => {
            if (document.body.style.overflow === 'hidden')
                document.body.style.overflow = 'auto';
        };
    }, [isInView]);

    // Cinematic transforms (scroll up & down)
    const pathLength = useTransform(scrollYProgress, [0, 1], [0, 1]);
    const blur = useTransform(scrollYProgress, [0, 1], [18, 0]);
    const spiralScale = useTransform(scrollYProgress, [0, 1], [0.7, 1.3]);
    const spiralRotate = useTransform(scrollYProgress, [0, 1], [-90, 120]);
    const spiralShadow = useTransform(
        scrollYProgress,
        [0, 1],
        ['0px 0px 80px #38bdf8', '0px 0px 240px #f8fafc']
    );
    const spiralGradient = useTransform(
        scrollYProgress,
        [0, 1],
        ['#38bdf8', '#f8fafc']
    );

    // Background radial glow, lebih dramatis
    const bgGlow = useTransform(
        scrollYProgress,
        [0, 1],
        [
            'radial-gradient(circle at 50% 50%, #38bdf8cc 0%, #0ea5e9 30%, #000 100%)',
            'radial-gradient(circle at 50% 50%, #f8fafc99 0%, #818cf8 40%, #000 100%)'
        ]
    );
    const bgOpacity = useTransform(scrollYProgress, [0, 1], [1, 0.7]);
    const bgScale = useTransform(scrollYProgress, [0, 1], [1, 1.12]);

    // Mouse icon
    const mouseOpacity = useTransform(scrollYProgress, [0, 0.18, 0.3], [1, 0.5, 0]);

    return (
        <div ref={triggerRef} className="h-screen w-full overflow-hidden">
            <motion.div
                className="fixed inset-0 z-50 flex flex-col items-center justify-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: isInView ? 1 : 0 }}
                transition={{ duration: 0.7, ease: [0.4, 2, 0.6, 1] }}
                style={{
                    pointerEvents: isInView ? 'auto' : 'none',
                    opacity: bgOpacity,
                    scale: bgScale,
                    background: bgGlow.get(),
                    transition: 'background 0.6s cubic-bezier(.4,2,.6,1)'
                }}
            >
                {/* Spiral Curve */}
                <motion.svg
                    viewBox="0 0 600 600"
                    className="absolute w-full h-full"
                    preserveAspectRatio="none"
                    style={{
                        opacity: 1,
                        filter: `blur(${blur.get()}px)`,
                        transformOrigin: 'center',
                        scale: spiralScale,
                        rotate: spiralRotate,
                        boxShadow: spiralShadow.get(),
                        zIndex: 1,
                        transition: 'all 0.6s cubic-bezier(.4,2,.6,1)'
                    }}
                >
                    <defs>
                        <linearGradient id="spiralGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stopColor={spiralGradient.get()} />
                            <stop offset="100%" stopColor="#818cf8" />
                        </linearGradient>
                    </defs>
                    <motion.path
                        d="
              M300,100 
              C280,140 320,160 300,200 
              C280,240 320,260 300,300 
              C280,340 320,360 300,400 
              C280,440 320,460 300,500"
                        stroke="url(#spiralGradient)"
                        strokeWidth="6"
                        fill="none"
                        strokeLinecap="round"
                        style={{ pathLength }}
                    />
                </motion.svg>

                {/* Scroll Mouse Icon */}
                <motion.div
                    className="mt-12 relative z-10 flex flex-col items-center gap-2"
                    style={{ opacity: mouseOpacity }}
                >
                    <motion.div
                        className="w-7 h-12 border-2 border-white rounded-full flex items-center justify-center"
                        animate={{ y: [0, 10, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                    >
                        <div className="w-1.5 h-3 bg-white rounded-full" />
                    </motion.div>
                    <p className="text-base text-white/80 text-center tracking-widest">Scroll down</p>
                </motion.div>

                {/* Scrollable Area */}
                <motion.div
                    ref={scrollRef}
                    className="absolute inset-0 h-full w-full overflow-y-scroll z-40"
                >
                    <div className="h-[300vh]" />
                </motion.div>
            </motion.div>
        </div>
    );
};

export default SkillsIntroScroll;
