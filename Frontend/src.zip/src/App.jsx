// src/App.jsx
import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from './components/Navbar';
import Profile from './components/Profile';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Experience from './components/Experience';
import EducationPage from './components/EducationPage';
import Layout from './components/Layout';
import LoadingScreen from './components/ui/LoadingScreen';
import ScrollProgress from './components/ui/ScrollProgress';
import FloatingElements from './components/ui/FloatingElements';
import CustomCursor from './components/ui/CustomCursor';

function App() {
    const [isLoading, setIsLoading] = useState(true);
    const [skillsStage, setSkillsStage] = useState('intro');

    const sectionRefs = {
        profile: useRef(null),
        skills: useRef(null),
        projects: useRef(null),
        experience: useRef(null),
        education: useRef(null),
        contact: useRef(null),
    };

    const handleNavigate = (sectionId) => {
        const targetRef = sectionRefs[sectionId];
        if (targetRef && targetRef.current) {
            // Special handling for skills section
            if (sectionId === 'skills' && skillsStage === 'intro') {
                // If skills is in intro stage, scroll to skills and let it handle the intro
                targetRef.current.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start',
                });
            } else {
                // Normal navigation
                targetRef.current.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start',
                });
            }
        }
    };

    // Handle skills stage changes
    const handleSkillsStageChange = (newStage) => {
        setSkillsStage(newStage);
    };

    useEffect(() => {
        const timer = setTimeout(() => setIsLoading(false), 2500);
        return () => clearTimeout(timer);
    }, []);

    useEffect(() => {
        if (!isLoading) {
            const hash = window.location.hash.substring(1);
            if (hash && sectionRefs[hash]) {
                setTimeout(() => {
                    handleNavigate(hash);
                }, 100);
            }
        }
    }, [isLoading, skillsStage]);

    // Handle scroll restoration
    useEffect(() => {
        const handleBeforeUnload = () => {
            sessionStorage.setItem('scrollPosition', window.scrollY);
        };

        const handleLoad = () => {
            const scrollPosition = sessionStorage.getItem('scrollPosition');
            if (scrollPosition) {
                window.scrollTo(0, parseInt(scrollPosition));
                sessionStorage.removeItem('scrollPosition');
            }
        };

        window.addEventListener('beforeunload', handleBeforeUnload);
        window.addEventListener('load', handleLoad);

        return () => {
            window.removeEventListener('beforeunload', handleBeforeUnload);
            window.removeEventListener('load', handleLoad);
        };
    }, []);

    return (
        <div className="relative min-h-screen bg-neutral-900 overflow-hidden">
            <AnimatePresence mode="wait">
                {isLoading ? (
                    <LoadingScreen key="loading" />
                ) : (
                    <motion.div
                        key="app"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.5 }}
                        className="relative z-10"
                    >
                        <Layout>
                            <CustomCursor />
                            <ScrollProgress />
                            <FloatingElements />
                            <Navbar onNavigate={handleNavigate} />

                            <Profile ref={sectionRefs.profile} />

                            <div ref={sectionRefs.skills}>
                                <Skills
                                    onStageChange={handleSkillsStageChange}
                                    currentStage={skillsStage}
                                />
                            </div>

                            <div ref={sectionRefs.projects}>
                                <Projects />
                            </div>

                            <div ref={sectionRefs.education}>
                                <EducationPage />
                            </div>

                            <div ref={sectionRefs.experience}>
                                <Experience />
                            </div>
                        </Layout>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

export default App;