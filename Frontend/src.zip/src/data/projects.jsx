export const projects = [
    {
        id: 1,
        title: 'E-Commerce Platform',
        category: 'Web Application',
        year: 2023,
        status: 'completed',
        technologies: ['React', 'Node.js', 'MongoDB', 'Stripe', 'Tailwind CSS'],
        description: 'Full-featured e-commerce platform with payment integration, user authentication, and admin dashboard.',
        image: '/images/projects/ecommerce.jpg', // Make sure this path exists
        githubUrl: 'https://github.com/username/ecommerce',
        liveUrl: 'https://ecommerce-demo.com'
    },
    {
        id: 2,
        title: 'Task Management App',
        category: 'Mobile Application',
        year: 2023,
        status: 'in progress',
        technologies: ['React Native', 'Firebase', 'Redux', 'Expo'],
        description: 'Cross-platform mobile app for team task management with real-time collaboration features.',
        image: '/images/projects/taskapp.jpg',
        githubUrl: 'https://github.com/username/taskapp',
        liveUrl: null
    },
    {
        id: 3,
        title: 'Portfolio Website',
        category: 'Web Application',
        year: 2023,
        status: 'completed',
        technologies: ['Next.js', 'TypeScript', 'Framer Motion', 'Tailwind CSS'],
        description: 'Modern portfolio website with smooth animations and responsive design.',
        image: '/images/projects/portfolio.jpg',
        githubUrl: 'https://github.com/username/portfolio',
        liveUrl: 'https://portfolio-demo.com'
    },
    {
        id: 4,
        title: 'Weather Dashboard',
        category: 'Web Application',
        year: 2022,
        status: 'planning',
        technologies: ['Vue.js', 'Chart.js', 'OpenWeather API'],
        description: 'Interactive weather dashboard with data visualization and location-based forecasts.',
        image: null, // No image available
        githubUrl: 'https://github.com/username/weather-dashboard',
        liveUrl: null
    }
];
