import {
    FiCode,
    FiServer,
    FiDatabase,
    FiSmartphone,
    FiGitBranch,
    FiLayers
} from 'react-icons/fi';

const skillsData = [
    {
        category: 'Frontend',
        description: 'Membangun antarmuka interaktif, responsif, dan modern untuk web dan mobile.',
        color: 'blue',
        icon: <FiCode />,
        technologies: [
            { name: 'JavaScript', icon: <FiCode />, color: 'text-yellow-400' },
            { name: 'React', icon: <FiCode />, color: 'text-cyan-400' },
            { name: 'Next.js', icon: <FiCode />, color: 'text-gray-200' },
            { name: 'Tailwind CSS', icon: <FiLayers />, color: 'text-sky-400' },
        ]
    },
    {
        category: 'Backend',
        description: 'Membangun API, otentikasi, dan logika bisnis yang scalable dan aman.',
        color: 'purple',
        icon: <FiServer />,
        technologies: [
            { name: 'Node.js', icon: <FiServer />, color: 'text-green-400' },
            { name: 'Express', icon: <FiServer />, color: 'text-gray-300' },
            { name: 'REST API', icon: <FiServer />, color: 'text-blue-400' },
        ]
    },
    {
        category: 'Database',
        description: 'Desain dan optimasi database relasional maupun non-relasional.',
        color: 'yellow',
        icon: <FiDatabase />,
        technologies: [
            { name: 'MongoDB', icon: <FiDatabase />, color: 'text-green-400' },
            { name: 'PostgreSQL', icon: <FiDatabase />, color: 'text-blue-400' },
            { name: 'MySQL', icon: <FiDatabase />, color: 'text-yellow-400' },
        ]
    },
    {
        category: 'Mobile',
        description: 'Pengembangan aplikasi mobile native dan hybrid.',
        color: 'pink',
        icon: <FiSmartphone />,
        technologies: [
            { name: 'React Native', icon: <FiSmartphone />, color: 'text-cyan-400' },
            { name: 'Flutter', icon: <FiSmartphone />, color: 'text-blue-400' },
        ]
    },
    {
        category: 'Version Control',
        description: 'Kolaborasi tim dan manajemen kode sumber dengan Git.',
        color: 'red',
        icon: <FiGitBranch />,
        technologies: [
            { name: 'Git', icon: <FiGitBranch />, color: 'text-red-400' },
            { name: 'GitHub', icon: <FiGitBranch />, color: 'text-gray-200' },
        ]
    },
    {
        category: 'UI Framework',
        description: 'Menggunakan framework UI modern untuk produktivitas dan konsistensi desain.',
        color: 'green',
        icon: <FiLayers />,
        technologies: [
            { name: 'Chakra UI', icon: <FiLayers />, color: 'text-green-400' },
            { name: 'Material UI', icon: <FiLayers />, color: 'text-blue-400' },
        ]
    }
];

export default skillsData;
